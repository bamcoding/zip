
public class java2 {

}
