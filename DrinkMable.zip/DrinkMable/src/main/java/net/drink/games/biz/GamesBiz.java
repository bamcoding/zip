package net.drink.games.biz;

public interface GamesBiz {

}
