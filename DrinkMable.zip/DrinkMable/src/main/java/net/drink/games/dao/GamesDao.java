package net.drink.games.dao;

public interface GamesDao {

}
