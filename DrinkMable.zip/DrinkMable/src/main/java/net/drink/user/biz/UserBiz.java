package net.drink.user.biz;

public interface UserBiz {

}
