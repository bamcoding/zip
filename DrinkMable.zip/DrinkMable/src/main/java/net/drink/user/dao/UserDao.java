package net.drink.user.dao;

public interface UserDao {

}
