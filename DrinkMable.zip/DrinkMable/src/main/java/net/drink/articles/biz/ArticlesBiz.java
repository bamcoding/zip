package net.drink.articles.biz;

public interface ArticlesBiz {

}
