package net.drink.articles.dao;

import net.drink.articles.vo.ArticlesVO;

public interface ArticlesDao {
	
	public int insert(ArticlesVO article);
	

}
