package net.drink.play.playVO;

public class PlayVO {

}
