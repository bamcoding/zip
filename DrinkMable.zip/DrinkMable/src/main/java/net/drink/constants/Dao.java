package net.drink.constants;

public interface Dao {

}
