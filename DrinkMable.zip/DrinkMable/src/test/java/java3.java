
public class java3 {

}
